
soljer - v1 2020-07-30 12:29am
==============================

This dataset was exported via roboflow.ai on July 30, 2020 at 4:29 AM GMT

It includes 22 images.
Soldier are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


